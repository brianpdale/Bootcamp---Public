
    function acceptcookies(){
        document.getElementById("cookies").style.display = 'none';
}

function changepic(myStr){
    var myelement = document.querySelector("#succulent1")
    myelement.src = myStr
}
function changepicback(myStr){
    var myelement = document.querySelector("#succulent1")
    myelement.src = myStr
}